from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
import json
import os
from pathlib import Path

router = APIRouter(prefix="/products", tags=["products"])

# Путь к JSON файлу
JSON_FILE_PATH = Path(__file__).parent.parent / "data" / "electronics.json"


def load_products() -> List[dict]:
    """Загрузить данные из JSON файла"""
    try:
        # Создаем директорию data если её нет
        JSON_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)

        if not JSON_FILE_PATH.exists():
            # Создаем дефолтные данные если файл не существует
            default_data = [
                {
                    "name": "iPhone 15 Pro",
                    "brand": "Apple",
                    "price": 99900,
                    "specs": "6.1-inch display, A17 Pro chip, 48MP camera"
                },
                {
                    "name": "Samsung Galaxy S24 Ultra",
                    "brand": "Samsung",
                    "price": 129999,
                    "specs": "6.8-inch display, Snapdragon 8 Gen 3, 200MP camera"
                },
                {
                    "name": "MacBook Pro 14",
                    "brand": "Apple",
                    "price": 199900,
                    "specs": "M3 Pro chip, 14-inch Liquid Retina, 18GB RAM"
                },
                {
                    "name": "Sony WH-1000XM5",
                    "brand": "Sony",
                    "price": 34900,
                    "specs": "Wireless noise-cancelling headphones, 30hr battery"
                },
                {
                    "name": "iPad Air",
                    "brand": "Apple",
                    "price": 69900,
                    "specs": "10.9-inch display, M1 chip, 64GB storage"
                },
                {
                    "name": "Dell XPS 15",
                    "brand": "Dell",
                    "price": 164900,
                    "specs": "15.6-inch OLED, Intel Core i7, 16GB RAM"
                },
                {
                    "name": "Samsung Galaxy Tab S9",
                    "brand": "Samsung",
                    "price": 79900,
                    "specs": "11-inch display, Snapdragon 8 Gen 2, S Pen included"
                },
                {
                    "name": "Logitech MX Master 3S",
                    "brand": "Logitech",
                    "price": 11900,
                    "specs": "Wireless mouse, 8000 DPI, silent clicks"
                }
            ]
            save_products(default_data)
            return default_data

        with open(JSON_FILE_PATH, 'r', encoding='utf-8') as file:
            return json.load(file)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка загрузки данных: {str(e)}")


def save_products(products: List[dict]) -> None:
    """Сохранить данные в JSON файл"""
    try:
        JSON_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(JSON_FILE_PATH, 'w', encoding='utf-8') as file:
            json.dump(products, file, ensure_ascii=False, indent=2)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка сохранения данных: {str(e)}")


def sort_products(products: List[dict], sorting: Optional[str] = None) -> List[dict]:
    """Сортировать продукты по названию"""
    if sorting == "asc":
        return sorted(products, key=lambda x: x["name"])
    elif sorting == "desc":
        return sorted(products, key=lambda x: x["name"], reverse=True)
    return products


def filter_by_brand(products: List[dict], brand: Optional[str] = None) -> List[dict]:
    """Фильтровать продукты по бренду"""
    if brand:
        return [item for item in products if item["brand"].lower() == brand.lower()]
    return products


# Получить список всех продуктов с возможностью сортировки и фильтрации
@router.get("/")
async def get_products(
        sorting: Optional[str] = Query(None, description="Сортировка по названию: asc (А-Я) или desc (Я-А)"),
        brand: Optional[str] = Query(None, description="Фильтр по бренду")
):
    """
    Получить все товары электроники с возможностью сортировки и фильтрации по бренду
    """
    products = load_products()

    # Применяем фильтр по бренду если указан
    products = filter_by_brand(products, brand)

    # Применяем сортировку если указана
    products = sort_products(products, sorting)

    return {
        "products": products,
        "total": len(products),
        "filters_applied": {
            "sorting": sorting,
            "brand": brand
        }
    }


# Поиск по бренду
@router.get("/search/")
async def search_by_brand(
        brand: str = Query(..., description="Название бренда для поиска"),
        sorting: Optional[str] = Query(None, description="Сортировка по названию: asc (А-Я) или desc (Я-А)")
):
    """
    Поиск товаров электроники по бренду
    """
    products = load_products()

    # Фильтруем по бренду
    filtered = [item for item in products if item["brand"].lower() == brand.lower()]

    if not filtered:
        raise HTTPException(status_code=404, detail=f"Товары бренда '{brand}' не найдены")

    # Применяем сортировку если указана
    filtered = sort_products(filtered, sorting)

    return {
        "products": filtered,
        "total": len(filtered),
        "brand": brand
    }


# Получить продукт по имени
@router.get("/{product_name}")
async def get_product_by_name(product_name: str):
    """
    Получить конкретный товар по названию
    """
    products = load_products()

    for product in products:
        if product["name"].lower() == product_name.lower():
            return product

    raise HTTPException(status_code=404, detail=f"Товар '{product_name}' не найден")


# Добавить новый продукт
@router.post("/")
async def create_product(
        name: str,
        brand: str,
        price: int,
        specs: str
):
    """
    Создать новый товар электроники
    """
    products = load_products()

    # Проверяем существует ли уже такой товар
    for product in products:
        if product["name"].lower() == name.lower():
            raise HTTPException(status_code=400, detail="Товар с таким названием уже существует")

    new_product = {
        "name": name,
        "brand": brand,
        "price": price,
        "specs": specs
    }

    products.append(new_product)
    save_products(products)

    return {
        "message": "Товар успешно создан",
        "product": new_product
    }


# Обновить продукт
@router.put("/{product_name}")
async def update_product(
        product_name: str,
        name: Optional[str] = None,
        brand: Optional[str] = None,
        price: Optional[int] = None,
        specs: Optional[str] = None
):
    """
    Обновить существующий товар электроники
    """
    products = load_products()

    for i, product in enumerate(products):
        if product["name"].lower() == product_name.lower():
            # Обновляем поля если они указаны
            if name:
                products[i]["name"] = name
            if brand:
                products[i]["brand"] = brand
            if price:
                products[i]["price"] = price
            if specs:
                products[i]["specs"] = specs

            save_products(products)
            return {
                "message": "Товар успешно обновлен",
                "product": products[i]
            }

    raise HTTPException(status_code=404, detail=f"Товар '{product_name}' не найден")


# Удалить продукт
@router.delete("/{product_name}")
async def delete_product(product_name: str):
    """
    Удалить товар электроники
    """
    products = load_products()

    for i, product in enumerate(products):
        if product["name"].lower() == product_name.lower():
            deleted_product = products.pop(i)
            save_products(products)
            return {
                "message": "Товар успешно удален",
                "deleted_product": deleted_product
            }

    raise HTTPException(status_code=404, detail=f"Товар '{product_name}' не найден")