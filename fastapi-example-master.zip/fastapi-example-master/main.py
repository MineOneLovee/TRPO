import logging

import uvicorn
from fastapi import FastAPI

from src.controllers.products import router as products_router

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Electronics Store API",
    description="API для интернет-магазина электроники",
    version="1.0.0",
)

app.include_router(products_router)

@app.get("/")
async def root():
    return {
        "message": "Добро пожаловать в API интернет-магазина электроники",
        "endpoints": {
            "GET /products": "Получить все товары (сортировка: asc/desc, фильтр по бренду)",
            "GET /products/search": "Поиск по бренду",
            "GET /products/{product_name}": "Получить товар по названию",
            "POST /products": "Создать новый товар",
            "PUT /products/{product_name}": "Обновить товар",
            "DELETE /products/{product_name}": "Удалить товар"
        }
    }

def main():
    logger.info('Запуск сервера...')
    uvicorn.run("main:app", host="0.0.0.0", port=8002, reload=True)

if __name__ == "__main__":
    main()